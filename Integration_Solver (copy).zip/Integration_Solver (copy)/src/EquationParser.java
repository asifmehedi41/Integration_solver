public class EquationParser {
}
